#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <fcntl.h>

#define SIZE sizeof(struct sockaddr_in)
#define BUF 1024

int main(void)
{
	int sockfd_listen;
	int sockfd_connect;
	char buf[BUF] = {0};

	int filehtml;
	ssize_t readhtml;
	char bufhtml[BUF] = {0};
	int lenhtml = 0;
	int conect_flag = 0;

	//--------------------------------------------------------------------------	

	char code_go[BUF] = {0};

	struct sockaddr_in server;

	server.sin_family = AF_INET; 
	server.sin_port = htons(5000);
	server.sin_addr.s_addr = htonl(INADDR_ANY);;

	//--------------------------------------------------------------------------	

	printf("socket 요청중입니다\n");
	if((sockfd_listen = socket(AF_INET, SOCK_STREAM, 0)) == -1)
	{
		printf("socket 요청에 실패했습니다\n");
		perror("오류 원인 : ");
		printf("\n프로그램을 종료합니다\n");
		exit(1);
	}
	printf("socket 요청에 성공했습니다\n");
	printf("----------------------------------\n");

	//--------------------------------------------------------------------------	

	printf("bind 요청중입니다\n");
	if((bind(sockfd_listen, (struct sockaddr *)&server, SIZE)) == -1)
	{
		printf("bind 요청에 실패했습니다\n");
		perror("오류 원인 : ");
		printf("\n프로그램을 종료합니다\n");
		exit(1);
	}	
	printf("bind 요청에 성공했습니다\n");
	printf("----------------------------------\n");

	//--------------------------------------------------------------------------	

	printf("listen 요청중입니다\n");
	if((listen(sockfd_listen, 5)) == -1)
	{
		printf("listen 요청에 실패했습니다\n");
		perror("오류 원인 : ");
		printf("\n프로그램을 종료합니다\n");
		exit(1);
	}	
	printf("listen 요청에 성공했습니다\n");	
	printf("----------------------------------\n");

	//--------------------------------------------------------------------------	
	while(1)
	{
		if(conect_flag == 0)
		{
			printf("client를 기다리는 중입니다\n");
			conect_flag = 1;
		}
		else
		{
			printf("client 재요청을 기다리는 중입니다\n");
		}
		
		if((sockfd_connect = accept(sockfd_listen, NULL, NULL)) == -1)
		{
			printf("client 연결에 실패했습니다\n");
			perror("오류 원인 : ");
			printf("\n프로그램을 종료합니다\n");
			exit(1);
		}
		printf("client와 연결되었습니다\n");
		printf("----------------------------------\n");

		//--------------------------------------------------------------------------	

		if((filehtml = open("syd_homepage.htm", O_RDWR)) == -1)
		{
			printf("html파일을 여는데 문제가 생겼습니다\n");
			perror("오류 원인 : ");
			printf("\n프로그램을 종료합니다\n");
			exit(1);
		}

		//--------------------------------------------------------------------------	

		while((readhtml = read(filehtml, bufhtml, BUF)) > 0)
			printf("다음 html소스를 보내겠습니다\n");
		printf("%s\n", bufhtml);

		lenhtml = strlen(bufhtml);
		printf("html소스 길이는 : %d\n", lenhtml);

		sprintf(code_go, "HTTP/1.1 200 ok\r\nContent-Length: %d\r\nContent-Type:text/html\r\n\n%s", lenhtml, bufhtml);

		//code_go = "HTTP/1.1 200 OK\nContent-Length: 19\nContent-Type: text/plain\n\r\nMy name is Junyeong";  	

		//printf("code_go 내용 : %s\n", code_go);
		printf("----------------------------------\n");

		//--------------------------------------------------------------------------	

		recv(sockfd_connect, buf,sizeof(buf),0);
		//perror("Recieve");

		send(sockfd_connect, code_go, strlen(code_go)+1, 0);
		//perror("Send");

		printf("server에서 보낸내용\n\n");
		printf("%s",code_go);	
		printf("----------------------------------\n");
	}	

	//--------------------------------------------------------------------------	

	printf("\nsocket 연결을 종료합니다\n");
	close(sockfd_listen);
	close(sockfd_connect);

	close(filehtml);

	return 0;
}
